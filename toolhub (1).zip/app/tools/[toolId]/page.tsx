import Link from "next/link"
import { Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { notFound } from "next/navigation"
import CodeFormatter from "@/components/tools/code-formatter"
import ColorPicker from "@/components/tools/color-picker"
import Calculator from "@/components/tools/calculator"
import PomodoroTimer from "@/components/tools/pomodoro-timer"
import MarkdownEditor from "@/components/tools/markdown-editor"
import UnitConverter from "@/components/tools/unit-converter"
import RandomPicker from "@/components/tools/random-picker"

export default function ToolPage({ params }: { params: { toolId: string } }) {
  const { toolId } = params

  const tools = {
    "code-formatter": {
      name: "Code Formatter",
      component: <CodeFormatter />,
      color: "bg-violet-50 dark:bg-violet-950",
      textColor: "text-violet-900 dark:text-violet-50",
      borderColor: "border-violet-200 dark:border-violet-800",
    },
    "color-picker": {
      name: "Color Picker",
      component: <ColorPicker />,
      color: "bg-pink-50 dark:bg-pink-950",
      textColor: "text-pink-900 dark:text-pink-50",
      borderColor: "border-pink-200 dark:border-pink-800",
    },
    calculator: {
      name: "Calculator",
      component: <Calculator />,
      color: "bg-blue-50 dark:bg-blue-950",
      textColor: "text-blue-900 dark:text-blue-50",
      borderColor: "border-blue-200 dark:border-blue-800",
    },
    pomodoro: {
      name: "Pomodoro Timer",
      component: <PomodoroTimer />,
      color: "bg-red-50 dark:bg-red-950",
      textColor: "text-red-900 dark:text-red-50",
      borderColor: "border-red-200 dark:border-red-800",
    },
    markdown: {
      name: "Markdown Editor",
      component: <MarkdownEditor />,
      color: "bg-emerald-50 dark:bg-emerald-950",
      textColor: "text-emerald-900 dark:text-emerald-50",
      borderColor: "border-emerald-200 dark:border-emerald-800",
    },
    converter: {
      name: "Unit Converter",
      component: <UnitConverter />,
      color: "bg-amber-50 dark:bg-amber-950",
      textColor: "text-amber-900 dark:text-amber-50",
      borderColor: "border-amber-200 dark:border-amber-800",
    },
    "random-picker": {
      name: "Random Picker",
      component: <RandomPicker />,
      color: "bg-purple-50 dark:bg-purple-950",
      textColor: "text-purple-900 dark:text-purple-50",
      borderColor: "border-purple-200 dark:border-purple-800",
    },
  } as const

  const tool = tools[toolId as keyof typeof tools]

  if (!tool) {
    notFound()
  }

  return (
    <div className={`min-h-screen ${tool.color}`}>
      <header
        className={`sticky top-0 z-50 w-full border-b ${tool.borderColor} backdrop-blur supports-[backdrop-filter]:bg-background/60`}
      >
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center space-x-2">
            <h1 className={`text-xl font-bold ${tool.textColor}`}>{tool.name}</h1>
          </div>
          <Link href="/" className="opacity-70 hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="sm" className="gap-1">
              <Home className="h-4 w-4" />
              <span className="text-xs">ToolHub</span>
            </Button>
          </Link>
        </div>
      </header>
      <main className="container py-6 md:py-12">{tool.component}</main>
      <footer className={`w-full border-t ${tool.borderColor} py-4`}>
        <div className="container flex justify-between items-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            &copy; {new Date().getFullYear()} ToolHub. All rights reserved.
          </p>
          <Link
            href="/"
            className="text-sm text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          >
            More Tools
          </Link>
        </div>
      </footer>
    </div>
  )
}
